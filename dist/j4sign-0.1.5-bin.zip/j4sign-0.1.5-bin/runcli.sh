#!/bin/bash

java -cp 'lib/*' it.trento.comune.j4sign.examples.CLITest "$1" "$2"

